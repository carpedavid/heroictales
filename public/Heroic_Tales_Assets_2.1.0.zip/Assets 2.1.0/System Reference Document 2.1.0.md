# System Reference Document 2.1.0

#### Credits

Version 2.1.0 • April 2022

> For Maya, Ava, and Rico, who are already on their way to being the most heroic of heroes.

Writing, design, artwork, and layout by David Garrett

Playtesting, additional game design, and eternally supportive friendship by Matt Friedlander, Rob Hays, David Kuchler, and Scott Perry.

Published by Amalara Game Studio

Heroic Tales System Reference Document copyright © 2022 by David Garrett. Licensed for use under the [Creative Commons Attribution 4.0](https://creativecommons.org/licenses/by/4.0/) license.

Made with ❤️ in Cleveland.

# Introduction

Heroic Tales is a genre-neutral role-playing system of heroic problem solving. It has a small, focused set of rules that is easy to pick up and learn, along with a modular set of subsystems that easily integrate to support many flavors of storytelling. What distinguishes it from other systems?

First, Heroic Tales is **narrative** — its mechanics are focused on the flow of the story rather than the tactical decisions of the characters. It has a **universal conflict resolution** mechanic so that the rules for resolving social interactions, combat, espionage, and any other type of challenge all work exactly the same way.

Heroic Tales manages character actions at the level of a scene or **challenge** rather than at the task or individual action level. This allows greater flexibility in how a player approaches a challenge and reduces the number of dice rolls needed to resolve a conflict.

Heroic Tales also supports both **solo** and **team games**. The conflict resolution mechanic scales from one player to six without any special adaptations.

Finally, Heroic Tales uses a **dice pool**, because rolling lots of dice is fun. In this system, players roll a set of six-sided dice (`d6`) in order to determine the results of their choices.

## System reference document

This **system reference document** (abbreviated SRD) contains all of the available mechanics for the Heroic Tales system as well as guidance on how to use them to create your own game. It is intended primarily for game designers and homebrewers — not directly for players.

This entire SRD is licensed under the Creative Commons Attribution 4.0 license, which gives you the right to use as many or as few of the concepts and words as you’d like in your own games, settings, adventures, and other content, as long as you make a clear statement that your material is based on these rules.

To do so, add the following text wherever you put your own copyright statement:

> This work is based on [Heroic Tales](https://heroictalesrpg.com) (https://heroictalesrpg.com), designed and authored by David Garrett and licensed for use under the [Creative Commons Attribution 4.0](https://creativecommons.org/licenses/by/4.0/) (https://creativecommons.org/licenses/by/4.0/) license.

If you’re publishing your work digitally, you can omit the printed URLs. As long as you adhere to these guidelines, you are also free to use the Heroic Tales icons to indicate compatibility with the Heroic Tales system.

## Using this document

Much of the text in the SRD is intentionally written in second person so that you can simply copy and paste it into your own game document, should you so choose.

> Designer comments are set apart from the rule text so that I can provide guidance and suggestions that you wouldn’t want to copy and paste.

`Keywords` are set in monospaced font in order to indicate that they have special meaning within the context of this game.

#### Rules of the game

> The core rules for challenge resolution and character creation should be applicable to most games that use the Heroic Tales system. Subsystems that can be added or removed without affecting the core rules follow in the “optional rules” chapter.

Heroic Tales is a storytelling game of heroic problem solving. To play it, you will adopt a persona called a `character` through whose eyes you will experience the story. Your character may adventure alone or with a group.

You will roll dice to determine how well your character navigates the obstacles they encounter during their adventures. Depending on how the dice fall, your character may achieve great success or endure terrible failure.

While the dice will determine whether your character succeeds or fails at a `challenge`, which represent the internal and external obstacles that stand in your way, you will always be in control of their thoughts and emotions. This is your story — if you're ever uncomfortable with how the game is progressing, you can make any change you feel appropriate.

> This is a good opportunity to set the stage for the player by including specifics about the role they’re playing, the world they’re playing in, and the nature of the challenges that they’re going to face.

## What you need to play

To play Heroic Tales, you’ll need the following in either analogue or digital form:

- An active imagination, a desire to be creative, and a place where you can focus.
- A journal, blank paper, or copies of the provided record sheets.
- A handful of six-sided dice (abbreviated `d6`).

# Rolling dice

When you’re asked to roll the dice, the text will tell you how many dice with a notation like `2d6`. That means you need to roll two six-sided dice at the same time and sum the results.

Occasionally, you’ll see a notation like `3d6+1`. In this case, roll three six-sided dice, sum the results, and then add one to the total. If you see `2d6×100`, that means roll two six-sided dice, sum the results, and then multiply the total by one hundred. Every time you see the `d6` notation, you need to sum the result of the dice roll before applying any other arithmetic.

The only exception is a special type of roll called `d66`. When you see this type of roll, use two six-sided dice, treating one die as the tens digit and the other as the ones digit. This will give you a range of results from eleven to sixteen, twenty-one to twenty-six, thirty-one to thirty-six, and so on.

> If your game doesn’t include the types of rolls in the second and third paragraphs above, feel free to omit them.

# Challenges

In Heroic Tales, the challenges that you face can be grouped into four broad categories:

- **Another character or group of characters** can be a direct challenge, as in a duel, or an indirect challenge, as in spreading vile rumors about you.
- **The environment** is often a source of significant challenges. Violent weather, difficult terrain, or ravenous creatures can be as dangerous as other characters.
- **You** may be your own greatest challenge. Depression, anxiety, self-doubt — every hero has their demons, and they are often hard to conquer. Making a strategic choice in the face of immediate gratification or resisting your natural instincts are other examples of internal conflicts.
- **Society** presents its own sets of challenges. Navigating societies other than your own can be fraught with peril. Greasing the wheels of bureaucratic institutions requires knowing the right people and processes. Cultural norms can limit your ability to take direct action, requiring you to indirectly accomplish your goals through influence and coercion.

> The preceding descriptions are an ideal place to work the specifics of your game into the rules. Mention the types of characters, specific environmental threats, and types of social challenges specific to your game and setting.

The difficulty of a challenge is measured by its `inertia`. An easy challenge has an inertia of two; normal, four; hard, six; tough, eight; and arduous, ten. Any obstacle more difficult than that is `impossible`, even for the mightiest hero.

![inertia.png](https://res.craft.do/user/full/87a38644-b365-8752-88ce-0450431154dc/doc/7B0DDCAC-4FD9-430C-91B0-9AFA407CEDAF/1A98C9BC-4166-4B95-87D8-979C66D9075E_2/z3dgo8I1L0BikSeNYkkAEqoCCOrAkzpAza7ayPZ4Qfwz/inertia.png)

Your ability to overcome a challenge is measured by your `momentum`*.* You start each challenge with two points of momentum.

To determine your character's progress, roll a set of six-sided dice equal to your `base dice` plus the dice from whichever of your character's three `traits` (body, mind, or spirit) is applicable. The description of each challenge will indicate which trait you should use. Some challenges will give you a choice of traits to use — in this case, choose the one with the highest rating. Add two dice if you gain `advantage` or subtract two dice if you suffer from `disadvantage`.

![dice_pool.png](https://res.craft.do/user/full/87a38644-b365-8752-88ce-0450431154dc/doc/7B0DDCAC-4FD9-430C-91B0-9AFA407CEDAF/1356F511-8BFB-4891-8BB6-155DC02A9F8F_2/ZEmwvpqz9aIse63lydW6Rrr684WL8ryeXq74yyUFOI8z/dice_pool.png)

The result of your die roll determines the outcome of your choices: how much progress you made in overcoming the inertia of the challenge and how much momentum you spent along the way.

All fours, fives, and sixes count as `successes`; threes are `neutral`; ones and twos count as `failures`. The result of your roll equals the total number of successes minus the total number of failures. You reduce the inertia of the challenge by the net number of successes that you generate.

![dice_results.png](https://res.craft.do/user/full/87a38644-b365-8752-88ce-0450431154dc/doc/7B0DDCAC-4FD9-430C-91B0-9AFA407CEDAF/2F0E6553-DAC9-42A7-8EB7-9FDC33C143CA_2/RdW9XWxaashaYZNTA10w3e0NzjyxJzEkxyj9vz0qbSEz/dice_results.png)

If you end up with more failures than successes, though, you lose one point of momentum. Despite your best efforts, you made things worse, not better.

Challenges are divided into `rounds` that represent a unit of effort from your character. Each round begins with your character observing the scene, continues with you determining your character's approach to overcoming the challenge, and ends when you roll the dice. Your character’s actions may take as long as needed to serve the story — neither a round nor a challenge has a fixed duration.

If, at the end of a round, you reduce the inertia of the challenge to zero or you lose your last point of momentum, then the challenge is over. Otherwise, begin another round. If you reduce a challenge’s inertia to zero as part of the same roll that exhausts your character’s momentum, then you are considered successful.

![flow_of_play.png](https://res.craft.do/user/full/87a38644-b365-8752-88ce-0450431154dc/doc/7B0DDCAC-4FD9-430C-91B0-9AFA407CEDAF/6F6F5E3B-1767-4BBA-825C-27316DBD7026_2/J645Sa1H7g9sBkBO2UOezEPFuibfPkOPvwQWKJxH0aEz/flow_of_play.png)

> I’ve found that adapting the charts and figures above to fit the styling of your game helps them blend in quite well. Even something as small as swapping the fonts and colors makes a big difference. They also help to break up what could otherwise be a very long block of fairly dry text.

## Advantage and disadvantage

Occasionally, your character will benefit from a condition favorable to them. The description of the challenge will alert you to this possibility. If you meet the conditions, then you gain `advantage` on your roll, adding two dice to your pool.

If, instead, your character suffers from some sort of impairment, then you suffer `disadvantage` on your roll — you subtract two from your pool. You always get to roll at least one die, even if suffering from disadvantage would reduce your pool to zero.

If your character is subject to multiple conditions that grant advantage or disadvantage, they do not combine. Advantage and disadvantage do cancel each other out, so if your character has two conditions causing advantage but one condition causing disadvantage, you still get advantage on your roll.

## Status effects

The world is filled with obstacles and wonders both great and small. Sometimes, interacting with those obstacles and wonders can cause `status effects`, which can positively or negatively affect your ability to overcome challenges by modifying one or more of your three traits: body, mind, and spirit. Positive status effects are called `buffs`, and grant you `advantage` when using the affected trait in a challenge. Negative conditions are called `debuffs` and confer `disadvantage` instead.

> This is a good place to provide a list of status effects that characters might encounter in your game.

Debuffs come in three varieties: `minor`, which resolve themselves after one challenge; `major`, which require specific remedies or a visit to a `haven` to remove; and `epic`, which require tackling a `challenge chain` to resolve.

> Your game may not have different levels of debuffs. If so, feel free to omit them.

## Hazardous environments

While some hazardous environments are simply too dangerous to interact with in any form, other environments are merely harmful to creatures who are not specifically adapted or equipped to deal with them. Unless you have special equipment or abilities designed to withstand a `hazardous environment`, you suffer `disadvantage` on all rolls while present there.

> Different game worlds are likely to have different types of hazardous environments. List the types of environments that a character might encounter as well as the type of equipment or abilities needed to protect against them.

## Havens

In contrast to hazardous environments, certain locations are considered safe havens.
When you reach a `haven`, you can rid yourself of any negative status effects.

> If your game doesn’t use status effects, hazardous environments, and havens, feel free to leave them out. I’ve included them here instead of the optional rules chapter because I feel that they’re likely to be relevant to more games than not.

# Challenge chains

In addition to individual `challenges`, which represent distinct obstacles, Heroic Tales also features `challenge chains`, which tie challenges together to create complex narrative arcs. In a challenge chain, your successes and failures in individual challenges build on each other to eliminate a `threat` or capture an `opportunity`.

Every challenge chain has a `trigger` and an `objective`. Challenge chains can be triggered by your actions, by the actions of other characters, by environmental factors, or simply by being in the right place at the right time.

When you trigger a challenge chain, select one `d6` to represent your character's progress. Begin with the 6 facing up — this is the `chain die`. Each time you successfully complete a challenge related to the chain, increase the count on the chain die by 1, to a maximum of 6. Each time you fail a challenge related to the challenge chain, decrease the chain die by 1.

If you complete the objective before the chain die reaches 1, then you successfully neutralize the threat or gain `rewards` from the opportunity. If the chain die reaches 1 *before* you complete the challenge chain's objective, however, then you either lose the opportunity or suffer `consequences` from the threat.

> In Wendigo, the entire game is a challenge chain. Your character’s progress feeling the titular monster is measured using an “escape die.” Depending on your game, changing the name of “challenge chain” to something genre-specific can really help to set the mood.

# Characters

Your character is a persona entirely of your creation. They might be an exact replica of you, or they can be someone of a different gender, sexuality, age, religion, ethnicity, or even species. Those details are entirely up to you. In addition to your character’s physical description and personality they possess a few attributes that affect gameplay.

## Traits

Your character has three traits that reflect general approaches to tackling a challenge: `body`, `mind`, and `spirit`.

- **Body** — you'll use your Body trait when you primarily rely on your physical skills and abilities to overcome a challenge.
- **Mind** — you'll use your Mind trait when you rely on pattern recognition, puzzle solving, or other analytical abilities.
- **Spirit** — use your Spirit trait when you primarily rely on your social skills and force of will to overcome an obstacle.

When you create your character, assign three dice to one trait, two dice to another, and one die to the last.

During each `round` of a `challenge`, you'll be prompted to use one of the three traits to reflect your character's actions. Some challenges will give you a choice of traits to use — in that case, use whichever trait gives you the best results.

## Talents

In addition to a set of traits, your character starts with a `talent` — an ability, item, or companion  — that aids you on your adventures.

During each `challenge`, when it makes narrative sense, you may use one of your talents to gain a beneficial effect on your roll. Choose one of the following effects each time you invoke your talent:

- Convert one `failure` to one `success`.
- Re-roll all `neutral` results.

As your character grows by advancing in `level`, you can add more talents which grant you additional opportunities to influence dice rolls. Regardless of how many talents you have available, though, you can only use one per round and can only invoke each talent once per challenge.

> Talents are a placeholder for genre or game-world specific effects. In **Space Junk** — a sci-fi game — characters gain virtual or robot companions. In Glorious Quest — a game of high fantasy — characters gain magical wonders.

> In a horror game, talents might be more prosaic. Characters in Wendigo, for example, can make use of camping gear to enhance their chances of escaping the terrifying monster.

## Advancement

Over time, you will learn, grow, and become better at what you do. Intelligent creatures are funny, though — we often learn more by failing than we do by completing a challenge successfully. Every time you fail a challenge, you gain one `experience point`. Each time you gain five experience points, your character's `level` increases by one.

As your level increases, you gain the following benefits:

- Each time you gain an odd level, increase the size of your `base dice` by one.
- Each time you gain an even level, you can add one additional `talent` to your character. You can use the powers of each talent you possess once per `challenge`.

The following table summarizes the effects of advancing your character’s level.

| **Level** | **Base Dice** | **Talents** |
| --------- | ------------- | ----------- |
| 1         | 1             | 1           |
| 2         | 1             | 2           |
| 3         | 2             | 2           |
| 4         | 2             | 3           |
| 5         | 3             | 3           |
| 6         | 3             | 4           |
| 7         | 4             | 4           |
| 8         | 4             | 5           |
| 9         | 5             | 5           |
| 10        | 5             | 6           |

> The concept of levels works well for games where a character grows and develops across multiple storylines. However, it isn’t applicable to games that have a limited scope or story.

> One way to encourage replay is to award the benefits gained each level at the end of each play-through. The player can then apply those benefits to the current character, or apply them directly to a new character for their next play-through.

> In Wendigo, for example, any individual character is only likely to run screaming through the woods once. Being able to apply the benefits to a new character gives the player an added boost.

#### Optional rules

> Each of these rules has a place in certain games to support specific styles of play. Collecting, for example, works well in a game where the core gameplay loop involves finding collectable goods, venturing to a haven, and then selling them for profit. Other gameplay loops will emphasize other activities. Feel free to pick and choose which rules support your game.

# Collecting

> Many games feature some sort of ability to collect raw goods. Fishing, foraging, mining, and salvaging are all examples of activities for which the collecting rules are appropriate.

Collecting raw goods requires that you complete a `challenge`. Each instance of raw goods is classified by the `type` of goods that can be collected and the `tier` of the challenge, which determines the difficulty and the potential value that can be retrieved during the challenge.

> List up to six types of goods for characters to collect.

The `inertia` of a collecting challenge is based on its tier:

- **Tier 1** — Easy
- **Tier 2** — Normal
- **Tier 3** — Hard
- **Tier 4** — Tough
- **Tier 5** — Arduous

If you successfully reduce the inertia of the challenge to zero before you lose all of your `momentum`, then you recover 2 units of `goods` of the site’s type and tier. An unsuccessful attempt retrieves only 1 unit.

To convert your goods to `credits (¢)`, you'll need to travel to a `haven`, where you can either take the default offering for your goods or `haggle`. If you choose to haggle, you have to take the value you roll.

| **Tier** | **Default** | **Haggle**    |
| -------- | ----------- | ------------- |
| 1        | 35          | 1d6x10        |
| 2        | 350         | 1d6x100       |
| 3        | 3,500       | 1d6x1,000     |
| 4        | 35,000      | 1d6x10,000    |
| 5        | 350,000     | 1d6x100,000   |
| 6        | 3,500,000   | 1d6x1,000,000 |

**Tier 6** goods can only be created through `refining`.

# Crafting

`Crafting` allows you to create an entirely new item by using a specific combination of `goods`. As long as it makes narrative sense, you can craft a new item by undertaking a `challenge`. The `inertia` of the challenge is determined by the complexity and quality of the item being created.

- Simple or rough (e.g. whittling a spoon with a pocket knife) — Easy
- Compound or plain (e.g. building a toy car from wood, screws, and paint) — Normal
- Sophisticated or fancy (e.g. building a couch) — Hard
- Complex or elegant (e.g. building a grandfather clock) — Tough
- Intricate or luxurious (e.g. building a pocket watch) — Arduous

If you are successful, then you craft the item at the level of quality that you were attempting to create. If you fail, then the goods you used are ruined and valueless.

> You’ll need to provide recipes for any goods that characters in your game can craft.

# Investigating

> In many games, characters will have to investigate mysteries. Simple mysteries can be resolved via a single challenge, while a complex mystery can merit a whole challenge chain. How you structure the mystery is up to you, but you can use the following rules to structure the challenge of investigating each clue.

When you undertake a `challenge` to investigate a mystery, you will inevitably discover some amount of information. The `inertia` of the challenge represents how readily that information can be obtained.

- Easy — you just need to know the right person to ask, and you’re pretty sure you know that person.
- Normal — it takes some research, but it’s nothing that someone couldn’t piece together given the time
- Hard — the clues are scattered all over, and it takes some guesswork and specialized knowledge to fit them together
- Tough — the clues require an insider or an expert to help unravel
- Arduous — time to get out the giant cork board and a ball of red twine

On a success, you manage to uncover the full set of information that you were searching for and are confident that the sources you used are trustworthy. On a failure, your information is either incomplete or untrustworthy, or both.

# Money

> In games where trade is common, everyone has some amount of access to currency and some ability to buy and sell goods.

Heroic Tales uses a generalized form of currency called *credits (¢)*. As a capable hero, you are assumed to have whatever basic supplies that you might need that are appropriate to the narrative.

You start the game with ¢500 worth of additional equipment and ¢500 in your wallet.

> Credits are merely a placeholder. If your game has a thriving economy, swap "credits" for the currency appropriate to your world. In Space Junk, the galaxy uses “points,” while in A Glorious Quest, the elves, humans, and dwarves of the world use a silver coin.

# Personality traits

These five traits are an optional but useful structure for developing your character's personality. You can choose a descriptive word for each trait from the following table, where the descriptive words are presented from low expression of the trait to high, or roll `2d6` for each to generate a personality.

- **Openness** describes your character’s appreciation for adventure, creativity, and emotion.
- **Conscientiousness** describes your character’s tendency to display self-discipline and be organized.
- **Extraversion** describes your character’s tendency to be outgoing and high in social energy.
- **Agreeableness** describes your character's general concern for social harmony.
- **Stability** describes your character’s tendency to be emotionally stable, especially when under pressure.

| **2d6** | **Openness** | **Conscientiousness** | **Extraversion** | **Agreeableness** | **Stability** |
| ------- | ------------ | --------------------- | ---------------- | ----------------- | ------------- |
| 2       | Close-minded | Irresponsible         | Solitary         | Manipulative      | Volatile      |
| 3       | Literal      | Sloppy                | Shy              | Aggressive        | Emotional     |
| 4       | Rigid        | Disorganized          | Reserved         | Callous           | Jumpy         |
| 5       | Analytical   | Spontaneous           | Quiet            | Selfish           | Nervous       |
| 6       | Knowledgable | Effective             | Sociable         | Gruff             | Pessimistic   |
| 7       | Smart        | Practical             | Friendly         | Hospitable        | Realistic     |
| 8       | Curious      | Reliable              | Energetic        | Polite            | Optimistic    |
| 9       | Imaginative  | Responsible           | Outgoing         | Kind              | Centered      |
| 10      | Artistic     | Careful               | Assertive        | Thoughtful        | Resilient     |
| 11      | Creative     | Cautious              | Noisy            | Helpful           | Calm          |
| 12      | Adventurous  | Serious               | Gregarious       | Generous          | Carefree      |

# Refining

Some characters are content to collect and sell, collect and sell, slowly building up the balance of credits in their wallets. Others, however, turn to `refining` their goods in order to increase their value.

Refining allows a character to combine two units of the same type and tier. Refining is a `challenge` that has an `inertia` determined by the tier of the goods being refined.

- **Tier 1** — Easy
- **Tier 2** — Normal
- **Tier 3** — Hard
- **Tier 4** — Tough
- **Tier 5** — Arduous

If the challenge is completed successfully, the two units of goods are combined into one unit of the next highest tier and the same type. If the challenge is failed, the two units of goods are rendered valueless.

# Team play

> While the Heroic Tales rules are written to be read by a solo player, it is also designed to be played with a team. In a team game, characters make decisions collectively.

## Character creation

The process for creating characters in a team game is largely the same as when playing a solo game with one significant exception — before you create individual characters, you’ll collectively create a backstory and reason for your characters to be part of the team.

> In a team game, the characters share any significant starting equipment. For example, the characters in Space Junk are all crew members of a single ship and make decisions on its maintenance and upgrades collectively.

## Challenges

In Heroic Tales, challenges are tackled collectively, and there is no benefit to one player rolling their dice before another. In fact, part of the fun of a team game is describing how your characters interact with each other and the world around you, and *then* rolling your dice at the same time to see how successful your actions were at resolving the challenge.

Heroic Tales scales the difficulty of challenges based on how many characters are part of the team. This allows any number of players to tell similar stories without penalizing small teams and solo play. Use the following chart to determine the `inertia` of the challenges you face as a team.

| **Team Members** | **Easy** | **Normal** | **Hard** | **Tough** | **Arduous** |
| ---------------- | -------- | ---------- | -------- | --------- | ----------- |
| 1                | 2        | 4          | 6        | 8         | 10          |
| 2                | 4        | 8          | 12       | 16        | 20          |
| 3                | 6        | 12         | 18       | 24        | 30          |
| 4                | 8        | 16         | 24       | 32        | 40          |
| 5                | 10       | 20         | 30       | 40        | 50          |
| 6                | 12       | 24         | 36       | 48        | 60          |

In a team game, each member brings two points of `momentum` to a challenge, which is pooled and shared by the team.

## Challenge chains

During a `challenge chain`, the team shares a single `chain die`. Choose one player to track the team's progress.

## Splitting the party

Heroic Tales assumes that team games should be collaborative in nature. While some characters may occasionally want to go one direction while others want to head in another, this is generally a bad idea, both for the fate of the characters and for the flow of play in real life.

Accordingly, the `inertia` of any challenge is based on the number of team members who start a game session, but each group only receives a pool of `momentum` equal to the number of characters present for the challenge.

#### Setting the scene

> The following are some tips on using the Heroic Tales rules to craft a compelling game.

# Tone

The Heroic Tales mechanics are adjusted to support a game that is heroic in tone, and heroes are expected to win in the end. Chance still very much plays a role — on their journey to heroic triumph, the character is likely to experience disappointment and failure — but fortune, in the form of probability, is very much on their side.

For that reason, Heroic Tales does not do grim and gritty well. Life is not fleeting and characters are not a dime a dozen. Danger comes in the form of setbacks that can be overcome, not, generally, in abrupt and abject failure.

Success is not guaranteed, though. When designing your game, you may wish to include the option for forcing a character to retire from play when it makes narrative sense — perhaps the character goes permanently mad from witnessing eldritch horrors or gets eaten by a wendigo. In this case, make the retirement a `consequence` of failing a `challenge chain`.

In Heroic Tales, character retirement should almost never be the consequence of a single `challenge`, but rather the culmination of a long string of bad luck and poor choices.

# Crafting challenges

As the game designer, you get the opportunity to craft the `challenges` that the players will attempt to overcome. A challenge can be anything from fighting a colossal, tentacled, city-devouring monster to developing the antidote for a magical zombie-creating poison. It could involve persuading the Grand Duchess to sponsor a voyage to the Islands East of Forever or it might involve helping an old, friendly vampire rescue his beloved spider-cat, Whiskers, from the Haunted Mines of Terror and Dread.

As a result, creating an engaging challenge is more of an art than a science. Therefore, it’s important to keep a few things in mind. First, make sure that your overall selection of challenges gives characters with different strengths a chance to shine. If every challenge is based on Spirit, for example, then characters who favor Body and Mind will be at a disadvantage.

Second, give the narrative a chance to ebb and flow. If every challenge is arduous, then monotony will set in. Varying the challenge level helps create a rhythm to the story — the players will get a chance to feel like champions when they complete an easy challenge and vulnerable when they tackle a tough one.

To create a compelling challenge, spend some time thinking through the following items:

- **Objective** — what is the character trying to accomplish?
- **Elements** — where and when does the challenge take place?
- **Obstacles, Timeframe, and Constraints** — what’s standing in the way of success, and what could cause them to fail?
- **Success and Failure** — what are the results of completing a challenge, both positive and negative?
- **Inertia** — how difficult is the challenge?

## Objective

Understanding the primary objective of a challenge is crucial for the player. What is their character trying to accomplish and why? Ambiguous goals will result in confused players.

## Elements

What can you describe to the players so that their characters have a sense of place and purpose? What does the location of the challenge look like? Sound like? Smell like? Are there people present? What are their names and personalities? Are there creatures? Monsters? Self-aware, super-intelligent math formulae?

You need not use flowery prose to describe a scene. Depending on the tone of your game, sometimes simple bullet points will do.

## Obstacles, timeframe, and constraints

First, what’s going to make the challenge a challenge? Something should be standing in the character’s way (sometimes literally) in order for there to be a chance of failure. There may be multiple obstacles. Fighting the giant demon on a slender bridge above a pit of bubbling lava is much more cinematic than fighting it in the middle of a featureless cavern.

Second, how long does the character have to successfully complete the challenge? Tasks that are, if not trivial, then straightforward when not constrained can become an extreme test when a tight deadline with serious consequences looms. For example, developing a magical potion that cures the crown princess’ petrified court might be important, but if a character can take their time, it will feel much less urgent than if they have to complete it by the next dawn.

Finally, what are the other boundaries of the challenge?  Does the character need to sneak into the rival gang-leader’s lair without being spotted? Do they need to navigate the minotaur’s maze without attracting its attention? Creative use of constraints can elevate a mundane challenge into one the players will remember.

## Success and failure

The player will eventually reduce the `inertia` of the challenge to zero or they will exhaust their `momentum`. What happens in either scenario?

Success should mean that the character achieves their objective in one form or another. If they are battling a great dragon, the dragon might surrender, it might die, or it might offer to trade its treasure horde for its life. If they are exploring the endlessly deep Höhle der Winde, success means making it through to the next waypoint without getting lost.

Failure can mean many things but it should always propel the narrative forward; failure should never mean that the story comes to a halt and the character gets stuck. Perhaps the great dragon physically picks them up and tosses them out of its lair. Perhaps the spelunkers wander, lost in the crevasses of Höhle der Winde, and make it to their checkpoint three days late, missing a key contact by a few hours.

## Inertia

Because the `inertia` of a challenge is determined both by the size of the group and the difficulty of the challenge, avoid using numbers directly in your game. Simply use the descriptive word (easy, normal, hard, tough, and arduous) and the players will be able to reference the target number based upon their group size during play.

